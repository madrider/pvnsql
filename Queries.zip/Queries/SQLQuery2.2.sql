--1
go

create function fun_grade(@sal int)

returns char as

begin

declare @grade as char;

select @grade=case

when @sal>=50000 then 'A'

when @sal>=25000 and @sal<50000 then 'B'


else 'C'

end;


return @grade;
end;

go


select staff_name,salary,dbo.fun_grade(salary) from staff_master;


--2
go

alter function calc_fine(@expdate date,@actdate date) returns int as

begin

declare @days as int;

declare @fine as int;


declare @curr as date;

declare @diff as int;

set @curr=GETDATE();

set @diff=DATEDIFF(dy,@expdate,@actdate);

if @diff<=0

return 0;

--if @days>0

set @days=datediff(dy,@expdate,@curr);

select @fine=case

when @days>0 then @days*5

else 0

end;

return @fine;

end;

go


select s.staff_code,s.staff_name,de.design_name,d.dept_name,bt.book_code,bm.book_name,bm.author,

dbo.calc_fine(bt.Exp_Return_date,Actual_Return_date) 'Fine'


 from book_master bm,book_transaction bt,Department_master d,Desig_master de,Staff_Master s where bt.Staff_code is not null and

s.dept_code=d.Dept_code and s.Des_Code=de.Design_Code and s.Staff_Code=bt.Staff_code and bt.Book_code=bm.Book_code;


--3
select staff_name from staff_master where mgr_code=(select mgr_code from Staff_Master where Staff_Code=100006);

--4
select s.stud_name,d.dept_name from Student_master s,Department_master d where s.Dept_Code=d.Dept_code and s.Stud_Code in (select stud_code from book_transaction where book_code in (select Book_code from Book_Transaction where staff_code is not null and Stud_code is not null));

--5

select author from Book_Master where book_category=(select book_category from Book_Master where Author='David Gladstone');

--6
go
alter function grade(@sub1 int,@sub2 int,@sub3 int) returns char as

begin

if(@sub1 is null or @sub2 is null or @sub3 is null)

return 'F';

declare @total as int

declare @grade as char

set @total=@sub1+@sub2+@sub3;

set @total=(@total)/3;

select @grade=case

when @total>80 then 'E'

when @total>=70 and @total<=80 then 'A'

when @total>=60 and @total<=69 then 'B'
else 'F'
end;
return @grade;
end;
go
select s.stud_code,s.stud_name,d.dept_name,coalesce(sm.subject1,0)+coalesce(sm.subject2,0)+coalesce(sm.subject3,0) 'Total Marks',dbo.grade(sm.subject1,sm.subject2,sm.subject3) 'Grade' from Student_master s,Student_Marks sm,Department_master d where s.Dept_Code=d.Dept_code and s.Stud_Code=sm.Stud_Code;