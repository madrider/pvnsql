select Book_Master.Book_name, count (Book_Transaction.Issue_date) as No_of_times_books_issued
from Book_Master join Book_Transaction 
on Book_Master.Book_code=Book_Transaction.Book_code
group by Book_name;