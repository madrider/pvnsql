create table contractors(
EmployeeID int not null primary key,
name varchar(255) null);
select * from Contractors;