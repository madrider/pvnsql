Use Northwind;

sp_help;

select @@version;

select getdate();

sp_help invoices;

use Training;

