create table employees(
EmployeeId int not null primary key,
name varchar(255) null
);

