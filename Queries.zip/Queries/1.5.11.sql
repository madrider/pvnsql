-- List out the names of all the books along with the author name, book code and 
--category which have not been issued at all. Try solving this question using EXISTS


select m.book_name, m.author,m.book_code, m.book_category from Book_Master m
join Book_Transaction on m.Book_code=Book_Transaction.Book_code
where Book_Transaction.Book_code not in (select Book_code from Book_Transaction);
