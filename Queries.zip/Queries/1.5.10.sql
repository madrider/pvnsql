--Display the Student Code, Student Name, and Department Name for that department in which maximum number of
--student are studying.

select s.Stud_Code, s.Stud_Name, d.Dept_Name from Student_master s join Department_master d on
s.Dept_Code=d.Dept_Code and d.Dept_code = (select top(1)Dept_Code from Student_master group by Dept_Code order by COUNT(Dept_Code) asc);-- as x on d.Dept_Code=t.Dept_Code;


