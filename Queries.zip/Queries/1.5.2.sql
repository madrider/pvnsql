select Staff_Master.Staff_Name, Department_master.Dept_code, Department_master.Dept_Name
from Staff_Master join Department_master 
on Staff_Master.Dept_Code=Department_master.Dept_code
where Department_master.Dept_code!=10;