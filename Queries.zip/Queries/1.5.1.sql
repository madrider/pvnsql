

select staff_master.staff_name, department_master.dept_code, department_master.dept_name, 
staff_master.Salary from staff_master
join department_master on Staff_Master.Dept_Code=Department_master.Dept_code where staff_master.salary>20000;