1.4.1 select stud_code,Stud_Name,Dept_Code from student_master;

1.4.2 select design_code,design_name from Desig_master;

select dept_code,dept_name from Department_master;

select stud_code, stud_year, subject1,subject2,subject3
from Student_Marks;

1.4.3 select staff_name,Salary,Dept_code from staff_master
where Dept_Code=30 or Dept_Code=40 or Dept_Code=20;

1.4.4 select stud_code,subject1+ subject2+subject3 as
 total_marks from student_marks;


 1.4.5 select book_name from Book_Master where book_name like 'An%';
 
1.4.6 select dept_code from student_master, Student_Marks where
 stud_year=2017;