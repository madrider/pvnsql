create table dbo.testrethrow
(
id int primary key
);