-- Create a non-clustered index for Book_Trans table on the following columns 
-- Book_code, Staff_name, student name, date of issue. Try adding some values.

GO
CREATE NONCLUSTERED INDEX idx_currate_notnull
ON Sales.SalesOrderHeader(CurrencyRateID)
WHERE CurrencyRateID IS NOT NULL;


create nonclustered index abc on book_transaction (book_code);

create nonclustered index abcd on book_transaction (staff_code);
create nonclustered index abcde on book_transaction (issue_date);
