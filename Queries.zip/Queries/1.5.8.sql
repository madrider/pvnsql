--List out the names of all student code whose score in subject1 is equal to the highest score

use Training;

select Student_master.Stud_Name, s.stud_code from Student_Marks s join
Student_master on s.Stud_Code=Student_master.Stud_Code
 where s.subject1 in (select max(subject1) from Student_Marks);
