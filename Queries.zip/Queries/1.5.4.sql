select Department_master.Dept_Name, count(Student_master.Stud_Code) as No_of_students
from Department_master join Student_master
on Department_master.Dept_code=Student_master.Dept_Code
group by Dept_Name;