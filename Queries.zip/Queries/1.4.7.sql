use Training;
select stud_name, DATENAME(MONTH,Stud_Dob)+ ', ' + DATENAME (day,stud_dob) +  ' '+
DATENAME (year,stud_dob) from student_master where DATENAME(WEEKDAY,stud_dob)='Saturday'
or DATENAME(WEEKDAY,stud_dob)='Sunday';