

set DATEFIRST 1;
use Training;
select staff_name,hiredate, datename(WEEKDAY,hiredate) as DAY from staff_master
ORDER BY DATEPART(dw,HireDate);