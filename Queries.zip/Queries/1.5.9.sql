--Modify the above query to display student names along with the codes.

use Training;

select Student_master.Stud_Name, s.stud_code from Student_Marks s join
Student_master on s.Stud_Code=Student_master.Stud_Code
 where s.subject1 in (select max(subject1) from Student_Marks);
