insert into Department_master values (100,'Home Science');
insert into Department_master values (200,'Home Science');
insert into Department_master values (300,'');
insert into Department_master values (400,'');



Msg 8115, Level 16, State 8, Line 1
Arithmetic overflow error converting int to data type numeric.
The statement has been terminated.
Msg 8115, Level 16, State 8, Line 2
Arithmetic overflow error converting int to data type numeric.
The statement has been terminated.
Msg 8115, Level 16, State 8, Line 3
Arithmetic overflow error converting int to data type numeric.
The statement has been terminated.
Msg 8115, Level 16, State 8, Line 4
Arithmetic overflow error converting int to data type numeric.
The statement has been terminated.
