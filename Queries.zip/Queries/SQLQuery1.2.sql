Use master
go

Select DB_NAME()
go


sp_help
go


Select @@version 
go


Select getdate()
go

sp_help Categories
go
