--1
select staff_code,staff_name,Dept_code from staff_master where datediff(y,year(hiredate),year(getdate())) >18;
--2
alter function countsalary(@price int) 

returns varchar(20) as

begin

declare @count int;

declare @string varchar(20);

set @count=@price/1000;

set @string='';

while @count > 0

begin

set @count = @count-1;

set @string = @string+'x';

end;

return @string;

end;
select dbo.countsalary(salary) as sal from staff_master;

--3
select book_code from Book_Transaction where Actual_Return_date is null;

--4
select staff_code from staff_master where month(staff_dob)= month(getdate());

--5
select count(*) from Book_Transaction where Actual_Return_date is not null ;

--6
select count(*) from Book_Master where book_category in ('Physics','Chemistry');

--7
select count(*) from Book_Transaction where datediff(d,Exp_Return_date,getdate()) = 0

--8
select max(salary) as Maximum,min(salary) as Minimum,avg(salary) as Average, sum(salary) as Total from staff_Master; 

--9
select count(distinct mgr_code) from staff_master;

--10
select Stud_Year,count(*) from Student_Marks where Subject1>=60 and Subject2>=60 and Subject3>60 group by Stud_Year;

--11
select d.dept_code,count(*) from Department_master d left join staff_master s on d.Dept_code = s.Dept_Code left join Student_master sm on d.Dept_Code= sm.Dept_Code group by d.dept_code having count(*)>10; 

--12
select sum(price) from book_master;

--13
select book_category,count(*) from book_master where price > 1000 group by book_category;

--14
select stud_name from Student_master where Dept_Code = (select dept_code from department_master where dept_name='Physics') and year(getdate())= (select stud_year from Student_Marks);
