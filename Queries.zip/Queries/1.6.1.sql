--Create a Unique index on Department Name for Department master Table.

use training;

CREATE INDEX xyz
ON department_master (dept_name);