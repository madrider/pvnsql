Display Staff Code, Staff Name, and Department Name for those who have taken 7.more than one book


use Training;
select staff_master.staff_code, staff_master.staff_name
from staff_master join Book_Transaction
 on Staff_Master.Staff_Code=Book_Transaction.Staff_code
 where Staff_Master.Staff_Code in
 (select Staff_code from Book_Transaction group by Staff_code having count(Book_code)>1 );