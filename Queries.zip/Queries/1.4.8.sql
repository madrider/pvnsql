select staff_code,staff_name,dept_code,hiredate,
DATEDIFF ( YEAR , Hiredate , '2017-11-10 16:50:00.0000000' ) as NoOfYears 
  from staff_master;
