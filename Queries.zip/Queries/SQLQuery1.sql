create table customers(
customerId int unique not null,
customerName varchar(20) not null,
Address1 varchar(30),
address2 varchar(30),
ContactNumber varchar(12),
PostalCode varchar(10));


CREATE TABLE Employees(
EmployeeId	INT NOT NULL PRIMARY KEY,
Name VARCHAR(255) not NULL);

CREATE TABLE Contractors(
ContractorId INT NOT NULL PRIMARY KEY,
Name VARCHAR(255) not NULL);

