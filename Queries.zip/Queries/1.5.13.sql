-- List out all the students who have not appeared for exams this year.


select Student_master.Stud_Name from Student_master
join Student_Marks 
on Student_master.Stud_Code=Student_Marks.Stud_Code
where Student_Marks.Subject1 is null and Student_Marks.Subject2 is null and Student_Marks.Subject3 is null;