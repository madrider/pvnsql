Use Training
go

--Create Table Customer with given fields
Create table Customer (
	Customerid int Unique NOT NULL,
	CustomerName varchar(20) NOT NULL,
	Address1 varchar(30),
	Address2 varchar(30),
	"Contact Number" varchar(12) NOT NULL,
	"Postal Code" varchar(10)
)
go

--Create Table Employees_ with given fields
CREATE TABLE Employees_
(
	EmployeeId INT NOT NULL PRIMARY KEY,
	Name NVARCHAR(255) NULL
)
go

--Create Table Contractors with given fields
CREATE TABLE Contractors
(
	ContractorId INT NOT NULL PRIMARY KEY,
	Name NVARCHAR(255) NULL
)
go

--Create Table TestRethrow with given fields
CREATE TABLE TestRethrow
(
	ID INT PRIMARY KEY
)
go

-- Create a user defined data type called Region, which would store a character string of size 15.
Create Type Region from varchar(15)
go

-- Create a Default which would store the value �NA� (North America�)
Create default "North America" as 'NA'
go

-- Bind the default to the Alias Data Type of Q1 i.e. region
EXEC sp_bindefault "North America",'Region'
go

-- Modify the table Customers to add the a column called Customer_Region which would be of data type: Region
Alter table Customers ADD Customer_Region Region
go

--Add the column to the Customer Table | Gender char (1)
Alter table Customer ADD Gender char(1)
go

-- Using alter table statement add a constraint to the Gender column such that it would not accept any other values except �M�,�F� and �T�.
Alter table Customer ADD Constraint Gender_Check Check (Gender = 'M' OR Gender = 'F' OR Gender = 'T')
go

-- Create Table Orders with given columns
Create table Orders_ (
	OrdersID int not null check (OrdersID > 1000), 
	CustomerId int not null, 
	OrdersDate Datetime,
	Order_State char(1) check (Order_State = 'P' OR Order_State = 'C')
)
go

-- Add referential integrity constraint for Orders & Customer tables through Customerld with the name fk_CustOrders.
Alter table Orders_ Add Foreign Key (OrdersID) References Customer(CustomerId)
go

-- Creating and Using Sequence Numbers
	-- Task 1 | Creating the Sequence
	USE Training
	go 
	CREATE SEQUENCE IdSequence AS INT START WITH 10000 INCREMENT BY 1
	go

	-- Task 2 � Using the Sequence to Insert New Rows
	USE Training
	go
	INSERT INTO Employees_ (EmployeeId, Name) VALUES (NEXT VALUE FOR IdSequence, 'Shashank')
	go
	INSERT INTO Contractors (ContractorId, Name) VALUES (NEXT VALUE FOR IdSequence, 'Aditya')
	go
	SELECT * FROM Employees_
	go
	SELECT * FROM Contractors
	go