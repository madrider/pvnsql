-- List out the code and names of all staff and students belonging to department 20

select staff_code,staff_name from Staff_Master
union select stud_code,stud_name from Student_master;