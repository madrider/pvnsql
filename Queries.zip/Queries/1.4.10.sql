select stud_name,dept_code, stud_dob from student_master where
Stud_Dob between '1981-01-01' and '1983-03-31';